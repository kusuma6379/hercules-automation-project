package TestClass;

import org.testng.annotations.Test;
import PageClasses.SurveyCreationPage;
import base.BaseTest;

public class SurveyCreationTest extends BaseTest {

    @Test
    public void surveyCreationFlowTest() {

        //  Create object using driver from BaseTest
        SurveyCreationPage survey = new SurveyCreationPage(driver);

        //  Step 1: Click Survey
        survey.clickSurvey();

        //  Step 2: Click Type of Survey
        survey.clickTypeOfSurvey();

        //  Step 3: Click Start Chat
        survey.clickStartChat();

        //  Final confirmation
        System.out.println(" Survey flow completed successfully up to Start Chat");
    }
}