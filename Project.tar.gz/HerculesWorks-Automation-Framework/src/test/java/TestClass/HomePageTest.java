package TestClass;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTest;
import PageClasses.HomePage;

public class HomePageTest extends BaseTest {

    @Test
    public void verifyHomePage() {

        // Create HomePage object
        HomePage home = new HomePage(driver);

        // Verify logo
        Assert.assertTrue(home.isLogoDisplayed(), "Logo is not displayed");

        // Click Research link
        home.clickResearch();

        // Click Sign Up button
        home.clickSignUp();
    }
}
