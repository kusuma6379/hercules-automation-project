package TestClass;

import org.testng.annotations.Test;

import PageClasses.PricingPage;
import base.BaseTest;

public class PricingTest extends BaseTest {

    @Test
    public void pricingFlowTest() throws InterruptedException {

        PricingPage page = new PricingPage(driver);

        page.clickPricing();
        System.out.println(" Pricing clicked");

        page.clickUpgrade();
        System.out.println(" Upgrade clicked");
    }
}