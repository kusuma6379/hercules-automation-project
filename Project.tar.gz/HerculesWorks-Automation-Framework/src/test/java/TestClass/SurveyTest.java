package TestClass;

import org.testng.annotations.Test;
import PageClasses.SurveyPage;
import base.BaseTest;

public class SurveyTest extends BaseTest {

    @Test
    public void surveyFlowTest() {

        SurveyPage survey = new SurveyPage(driver);

        survey.clickTryHercules();
        survey.login("kusumamadavali22@gmail.com", "Kusuma@123");
        survey.clickViewAll();

        System.out.println("➡️ View All clicked");

        
    }
}