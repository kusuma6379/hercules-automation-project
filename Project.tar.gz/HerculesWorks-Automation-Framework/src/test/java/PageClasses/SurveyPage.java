package PageClasses;

import java.time.Duration;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

public class SurveyPage {

    WebDriver driver;
    WebDriverWait wait;

    public SurveyPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    //  Locators
    By tryHercules = By.xpath("//span[contains(text(),'Hercules')]");

    By emailField = By.xpath("//input[@placeholder='Enter your email']");
    By passwordField = By.xpath("//input[@placeholder='Enter your password']");
    By loginBtn = By.xpath("//button[contains(text(),'Log')]");

    By viewAllBtn = By.xpath("(//*[text()='View All'])[2]");
   


    //  Click Try Hercules
    public void clickTryHercules() {

        WebElement element = wait.until(
                ExpectedConditions.visibilityOfElementLocated(tryHercules));

        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView(true);", element);

        try {
            wait.until(ExpectedConditions.elementToBeClickable(element)).click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
    }


    //  Login
    public void login(String email, String password) {

        WebElement emailEl = wait.until(
                ExpectedConditions.visibilityOfElementLocated(emailField));
        emailEl.sendKeys(email);

        WebElement passEl = driver.findElement(passwordField);
        passEl.sendKeys(password);

        WebElement loginButton = driver.findElement(loginBtn);

        try {
            wait.until(ExpectedConditions.elementToBeClickable(loginButton)).click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", loginButton);
        }
    }


    //  Click View All
    public void clickViewAll() {

        WebElement element = wait.until(
                ExpectedConditions.visibilityOfElementLocated(viewAllBtn));

        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView(true);", element);

        try {
            wait.until(ExpectedConditions.elementToBeClickable(element)).click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
    }
  
}