package PageClasses;

import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

public class SurveyCreationPage {

    WebDriver driver;
    WebDriverWait wait;

    public SurveyCreationPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    //  Locators
    By surveyBtn = By.xpath("//span[text()='survey']");
    By typeOfSurvey = By.xpath("//p[text()='Type of survey']");
    By startChatBtn = By.xpath("(//div[@class='flex items-center justify-center'])[1]");


    //  Utility: wait for full page load
    public void waitForPageLoad() {
        wait.until(webDriver ->
            ((JavascriptExecutor) webDriver)
                .executeScript("return document.readyState")
                .equals("complete")
        );
    }


    //  Step 1: Click Survey
    public void clickSurvey() {

        WebElement el = wait.until(
            ExpectedConditions.elementToBeClickable(surveyBtn)
        );

        el.click();

        waitForPageLoad();
    }


    //  Step 2: Click Type of Survey
    public void clickTypeOfSurvey() {

        WebElement el = wait.until(
            ExpectedConditions.elementToBeClickable(typeOfSurvey)
        );

        el.click();

        waitForPageLoad();
    }


    //  Step 3: Click Start Chat (FINAL STABLE VERSION)
    public void clickStartChat() {

        waitForPageLoad();

        WebElement el = wait.until(
            ExpectedConditions.elementToBeClickable(startChatBtn)
        );

        try {
            el.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver)
                .executeScript("arguments[0].click();", el);
        }

        waitForPageLoad();

        System.out.println("✅ Start Chat page opened successfully");
    }
}