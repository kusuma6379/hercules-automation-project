package PageClasses;   // we can later rename to "pages"

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {

    WebDriver driver;

    // Constructor
    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    // Locators
    By logo = By.xpath("(//img[@alt='hercules-logo'])[1]");
    By researchLink = By.xpath("//li[text()='Research']");
    By signUpButton = By.xpath("//button[text()='Sign Up']");

    // Methods

    // Check logo
    public boolean isLogoDisplayed() {
        return driver.findElement(logo).isDisplayed();
    }

    // Click Research link
    public void clickResearch() {
        driver.findElement(researchLink).click();
    }

    // Click Sign Up button
    public void clickSignUp() {
        driver.findElement(signUpButton).click();
    }
}