package PageClasses;


import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class PricingPage {

    WebDriver driver;

    public PricingPage(WebDriver driver) {
        this.driver = driver;
    }

    // Click Pricing using JavaScript (handles dynamic header)
    public void clickPricing() throws InterruptedException {

        Thread.sleep(5000); // wait for page fully load

        JavascriptExecutor js = (JavascriptExecutor) driver;

        js.executeScript(
            "document.querySelectorAll('a').forEach(el => {" +
            "if(el.innerText.includes('Pricing')) el.click();" +
            "});"
        );

        Thread.sleep(5000); // wait for navigation
    }

    // Click Upgrade button inside pricing cards
    public void clickUpgrade() throws InterruptedException {

        Thread.sleep(5000);

        JavascriptExecutor js = (JavascriptExecutor) driver;

        js.executeScript(
            "document.querySelectorAll('span').forEach(el => {" +
            "if(el.innerText.toLowerCase().includes('upgrade')) el.click();" +
            "});"
        );
    }
}